# 2.prak_darbs
Tiešsaistes čata sistēma, kuru var lietot jeb kurš tīmekļa lietotājs, kurš būs veiksmīgi autentificējies sistēmā (reģistrējies/ielogojies). 
Lietotne piedāvās vairākas iepriekš izveidotas čata istabas, kurā jeb kurš var kaut ko ierakstīt. Būs iespēja arī sazināties ar katru lietotāju personīgi.
Izveidot arī moderatora profilu, kurš varētu kontrolēt lietotājus, izmest no sistēmas, dzēst ziņu, ja nepieciešams.